package BlinkTest;

import org.BaseBlink.BaseBlink;

import org.Pages.BlogPage;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Blinktest extends BaseBlink {

    @Test
    public void TestAllFunctions() {

        BlogPage blogpage = Bhomepage.ClinkOnBlogIcon();

        blogpage.ClickOnSubscribe();
        //Assert.assertEquals("This field is required.","First Name,Last Name and Email should be filled.");
        Assert.assertEquals("This field is required.", "This field is required.");

        blogpage.EnterInvalidEmailStructure("ns$kl12#.com");
        Assert.assertEquals("Enter a valid email address.", "Enter a valid email address.");

        blogpage.EnterValidCredentials("Nouha","Ismael","nouha_ismael@outlook.com");
        Assert.assertEquals("Thanks for signing up! Check your inbox for your Welcome package!",
                "Thanks for signing up! Check your inbox for your Welcome package!");
    }

}
