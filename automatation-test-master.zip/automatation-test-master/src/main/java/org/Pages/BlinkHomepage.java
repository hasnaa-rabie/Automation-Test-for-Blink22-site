package org.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.concurrent.TimeUnit;

public class BlinkHomepage {

    public WebDriver driver;

    public BlinkHomepage (WebDriver driver){
        this.driver = driver;
    }

    /*public void ClickOnAccceptButton(){
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.className("btn btn-block accept-cookies")).click();
    }*/

    public BlogPage ClinkOnBlogIcon (){
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
        driver.findElement(By.xpath("//a[normalize-space()='BLOG']")).click();
        //driver.findElement(By.cssSelector(".active\n")).click();
        return new BlogPage(driver);
    }

}
